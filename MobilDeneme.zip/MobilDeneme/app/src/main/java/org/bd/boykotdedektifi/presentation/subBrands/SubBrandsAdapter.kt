package org.bd.boykotdedektifi.presentation.subBrands

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.navigation.NavDirections
import androidx.navigation.Navigation
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import coil.load
import org.bd.boykotdedektifi.data.Brand
import org.bd.boykotdedektifi.databinding.CardSubBrandsBinding

class SubBrandsAdapter() : RecyclerView.Adapter<SubBrandsAdapter.CardViewHolder>()
{
 inner class CardViewHolder(val binding: CardSubBrandsBinding) : RecyclerView.ViewHolder(binding.root)

    private val diffCallback = object : DiffUtil.ItemCallback<Brand>(){
        override fun areContentsTheSame(oldItem: Brand, newItem: Brand): Boolean {
            return oldItem == newItem
        }

        override fun areItemsTheSame(oldItem: Brand, newItem: Brand): Boolean {
            return oldItem.id == newItem.id
        }
    }

    private val differ = AsyncListDiffer(this, diffCallback)

    fun submitList(list : List<Brand>) = differ.submitList(list)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardViewHolder {

        return CardViewHolder(
            CardSubBrandsBinding.inflate(
                LayoutInflater.from(parent.context), parent, false
            )
        )
    }

    override fun getItemCount() = differ.currentList.size

    override fun onBindViewHolder(holder: CardViewHolder, position: Int) {

        val brand = differ.currentList[position]

        val truncatedName = if (brand.name.length > 8) {
            "${brand.name.substring(0, 8)}..."
        } else {
            brand.name
        }

        holder.binding.apply {
            textViewSubBrandName.text = truncatedName
            imageViewSubBrand.load(brand.image)
            cardViewSubBrand.setOnClickListener {view->
                val action : NavDirections = SubBrandsFragmentDirections.fromSubBrandsToDetails(brand)
                Navigation.findNavController(view).navigate(action)
            }
        }
    }
}