package org.bd.boykotdedektifi.presentation.mainBrands

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import kotlinx.coroutines.flow.MutableStateFlow
import org.bd.boykotdedektifi.R
import org.bd.boykotdedektifi.databinding.DialogRecommendProductBinding
import org.bd.boykotdedektifi.databinding.FragmentMainBrandsBinding
import org.bd.boykotdedektifi.utils.BrandsList

class MainBrandsFragment : Fragment() {

    private lateinit var binding: FragmentMainBrandsBinding
    private lateinit var brandsAdapter: BrandsAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = DataBindingUtil.inflate(inflater,R.layout.fragment_main_brands,container,false)
        setupRV()
        setupBarcodeScanner()
        setupSearchBar()
        return binding.root
    }

    private fun setupBarcodeScanner() {
        binding.cardScanBarcode.setOnClickListener {
            context?.let { context ->
                val options = GmsBarcodeScannerOptions.Builder()
                    .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS)
                    .build()
                val scanner = GmsBarcodeScanning.getClient(context, options)
                val barCodeResults = MutableStateFlow<String?>(null)

                scanner.startScan()
                    .addOnSuccessListener { barcode ->
                        barCodeResults.value = barcode.rawValue
                        Log.e("TAG", barcode.rawValue.orEmpty())
                        showAlertDialog(context, message = barcode.rawValue.orEmpty())
                    }
                    .addOnFailureListener { e ->
                        Log.d("CODE_SCAN_FAILED", e.message.toString())
                    }
                    .addOnCompleteListener { task ->
                        if (task.isCanceled) {
                            Log.e("TAG", "Scan was canceled")
                        }
                    }
            }
        }
    }

    private fun showAlertDialog(context: Context, title: String = "Result", message: String = "") {
        AlertDialog.Builder(context)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Tamam") { dialog, _ ->
                dialog.dismiss()
            }
            .create()
            .show()
    }

    private fun setupRV()
    {
        brandsAdapter = BrandsAdapter()
        binding.rv.apply {
            adapter=brandsAdapter
            layoutManager = GridLayoutManager(context,3)
            setHasFixedSize(true)
        }
        brandsAdapter.submitList(BrandsList.brandsList)
    }

    private fun setupSearchBar() {
        binding.editTextSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterBrands(s.toString())
            }

            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun filterBrands(query: String) {
        val filteredList = BrandsList.brandsList.filter { it.name.contains(query, true) }
        if (filteredList.isEmpty()) {
            binding.rv.visibility = View.INVISIBLE
            showRecommendProductDialog()
        } else {
            binding.rv.visibility = View.VISIBLE
            brandsAdapter.submitList(filteredList)
        }
    }

    private fun showRecommendProductDialog() {
        val inflater = LayoutInflater.from(context)
        val dialogBinding: DialogRecommendProductBinding = DataBindingUtil.inflate(inflater, R.layout.dialog_recommend_product, null, false)
        val alertDialog = AlertDialog.Builder(requireContext())
            .setView(dialogBinding.root)
            .create()
        alertDialog.show()

        dialogBinding.imageViewClose.setOnClickListener {
            alertDialog.dismiss()
        }
    }
}