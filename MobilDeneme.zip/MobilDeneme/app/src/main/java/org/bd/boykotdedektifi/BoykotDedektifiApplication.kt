package org.bd.boykotdedektifi

import android.app.Application

class BoykotDedektifiApplication: Application()