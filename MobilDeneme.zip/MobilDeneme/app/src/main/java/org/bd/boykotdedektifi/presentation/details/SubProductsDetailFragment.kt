package org.bd.boykotdedektifi.presentation.details

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import coil.load
import org.bd.boykotdedektifi.R
import org.bd.boykotdedektifi.data.Brand
import org.bd.boykotdedektifi.databinding.FragmentSubProductsDetailBinding

class SubProductsDetailFragment : Fragment() {

    private lateinit var binding: FragmentSubProductsDetailBinding
    private val brand: Brand by lazy { args.BrandsInfo }
    private val args by navArgs<SubProductsDetailFragmentArgs>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = DataBindingUtil.inflate(inflater,R.layout.fragment_sub_products_detail,container,false)

        setupUI()

        return binding.root
    }

    private fun setupUI() {
        with(binding) {
            imageViewBack.setOnClickListener {
                findNavController().popBackStack()
            }
            imageViewSubBrand.load(brand.image)
            textViewSubBrandName.text = brand.name
            imageViewPress.load(brand.image)
            textViewBrandNameProofPress.text = brand.name
            imageViewTwitter.load(brand.image)
            textViewBrandNameProofTwitter.text = brand.name
        }
    }
}