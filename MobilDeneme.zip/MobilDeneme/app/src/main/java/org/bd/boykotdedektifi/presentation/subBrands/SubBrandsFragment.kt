package org.bd.boykotdedektifi.presentation.subBrands

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import coil.load
import org.bd.boykotdedektifi.R
import org.bd.boykotdedektifi.data.Brand
import org.bd.boykotdedektifi.databinding.FragmentSubBrandsBinding

class SubBrandsFragment : Fragment() {

    private lateinit var binding: FragmentSubBrandsBinding
    private lateinit var brand:Brand
    private val args by navArgs<SubBrandsFragmentArgs>()
    private lateinit var subBrandsAdapter: SubBrandsAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = DataBindingUtil.inflate(inflater,R.layout.fragment_sub_brands,container,false)
        brand=args.BrandsInfo

        setupUI()
        setupRV()

        return binding.root
    }

     private fun setupRV()
     {
         subBrandsAdapter = SubBrandsAdapter()
         binding.rv.apply {
             adapter=subBrandsAdapter
             layoutManager = LinearLayoutManager(context)
             setHasFixedSize(true)
         }
         subBrandsAdapter.submitList(brand.subList)
     }

    private fun setupUI() {
        with(binding) {
            imageViewBack.setOnClickListener {
                findNavController().popBackStack()
            }
            textViewSubBrandName.text = brand.name
            imageViewSubBrandImage.load(brand.image)
        }
    }
}