package org.bd.boykotdedektifi.data

import android.os.Parcelable

@kotlinx.parcelize.Parcelize
data class Brand(val id: Int, val name: String, val image : String, val subList : List<Brand> = emptyList()) : Parcelable
