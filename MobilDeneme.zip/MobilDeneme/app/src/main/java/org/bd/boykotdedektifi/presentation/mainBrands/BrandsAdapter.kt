package org.bd.boykotdedektifi.presentation.mainBrands

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.navigation.NavDirections
import androidx.navigation.Navigation
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import coil.load
import org.bd.boykotdedektifi.data.Brand
import org.bd.boykotdedektifi.databinding.CardMainBrandsBinding

class BrandsAdapter() : RecyclerView.Adapter<BrandsAdapter.CardViewHolder>()
{
    inner class CardViewHolder(val binding: CardMainBrandsBinding) : RecyclerView.ViewHolder(binding.root)

    private val diffCallback = object : DiffUtil.ItemCallback<Brand>(){
        override fun areContentsTheSame(oldItem: Brand, newItem: Brand): Boolean {
            return oldItem == newItem
        }

        override fun areItemsTheSame(oldItem: Brand, newItem: Brand): Boolean {
            return oldItem.id == newItem.id
        }
    }

    private val differ = AsyncListDiffer(this, diffCallback)

    fun submitList(list : List<Brand>) = differ.submitList(list)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardViewHolder {

        return CardViewHolder(
            CardMainBrandsBinding.inflate(
                LayoutInflater.from(parent.context), parent, false
            )
        )
    }

    override fun getItemCount() = differ.currentList.size

    override fun onBindViewHolder(holder: CardViewHolder, position: Int) {

        val brand = differ.currentList[position]

        val truncatedName = if (brand.name.length > 8) {
            "${brand.name.substring(0, 8)}..."
        } else {
            brand.name
        }

        holder.binding.apply {
            textViewBrandName.text = truncatedName

            imageViewBrand.load(brand.image)

            cardViewMainBrand.setOnClickListener{view->
                val action : NavDirections = MainBrandsFragmentDirections.fromMainBrandsListToSubBrandsList(brand)
                Navigation.findNavController(view).navigate(action)
            }
        }
    }
}