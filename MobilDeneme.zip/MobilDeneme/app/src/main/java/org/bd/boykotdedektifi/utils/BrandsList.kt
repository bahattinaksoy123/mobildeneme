package org.bd.boykotdedektifi.utils

import org.bd.boykotdedektifi.data.Brand

object BrandsList
{
    val adidasSubList = listOf(
        Brand(1, "Sub1Adidas", "https://w7.pngwing.com/pngs/578/20/png-transparent-adidas-adidas-angle-text-logo.png"),
        Brand(2, "Sub2Adidas", "https://w7.pngwing.com/pngs/578/20/png-transparent-adidas-adidas-angle-text-logo.png"),
        Brand(3, "Sub3Adidas", "https://w7.pngwing.com/pngs/578/20/png-transparent-adidas-adidas-angle-text-logo.png"),
        )

    val algidaSubList = listOf(
        Brand(1, "Sub1Algida", "https://w7.pngwing.com/pngs/504/936/png-transparent-ice-cream-good-humor-logo-wall-s-ice-cream.png"),
        Brand(2, "Sub2Algida", "https://w7.pngwing.com/pngs/504/936/png-transparent-ice-cream-good-humor-logo-wall-s-ice-cream.png"),
        Brand(3, "Sub3Algida", "https://w7.pngwing.com/pngs/504/936/png-transparent-ice-cream-good-humor-logo-wall-s-ice-cream.png"),
        )

    val cappySubList = listOf(
        Brand(1, "Sub1Cappy", "https://w7.pngwing.com/pngs/852/171/png-transparent-juice-cappy-squash-the-coca-cola-company-orange-juice-text-label-rectangle.png"),
        Brand(1, "Sub2Cappy", "https://w7.pngwing.com/pngs/852/171/png-transparent-juice-cappy-squash-the-coca-cola-company-orange-juice-text-label-rectangle.png"),
        Brand(1, "Sub3Cappy", "https://w7.pngwing.com/pngs/852/171/png-transparent-juice-cappy-squash-the-coca-cola-company-orange-juice-text-label-rectangle.png"),
    )
    val cocacolaSubList = listOf(
        Brand(1, "Sub1CocaCola", "https://w7.pngwing.com/pngs/717/116/png-transparent-coca-cola-logo-coca-cola-logo-company-business-cola-company-text-photography.png"),
        Brand(2, "Sub2CocaCola", "https://w7.pngwing.com/pngs/717/116/png-transparent-coca-cola-logo-coca-cola-logo-company-business-cola-company-text-photography.png"),
        Brand(3, "Sub3CocaCola", "https://w7.pngwing.com/pngs/717/116/png-transparent-coca-cola-logo-coca-cola-logo-company-business-cola-company-text-photography.png"),
    )
    val danoneSubList = listOf(
        Brand(1, "Sub1Danone", "https://w7.pngwing.com/pngs/927/362/png-transparent-danone-logo-business-corporation-durex-blue-text-label.png"),
        Brand(2, "Sub2Danone", "https://w7.pngwing.com/pngs/927/362/png-transparent-danone-logo-business-corporation-durex-blue-text-label.png"),
        Brand(3, "Sub3Danone", "https://w7.pngwing.com/pngs/927/362/png-transparent-danone-logo-business-corporation-durex-blue-text-label.png"),
    )
    val laysSubList = listOf(
        Brand(1, "Sub1Lays", "https://w7.pngwing.com/pngs/559/457/png-transparent-lay-s-logo-lay-s-logo-potato-chip-frito-lay-brand-chips-miscellaneous-food-trademark.png"),
        Brand(2, "Sub2Lays", "https://w7.pngwing.com/pngs/559/457/png-transparent-lay-s-logo-lay-s-logo-potato-chip-frito-lay-brand-chips-miscellaneous-food-trademark.png"),
        Brand(3, "Sub3Lays", "https://w7.pngwing.com/pngs/559/457/png-transparent-lay-s-logo-lay-s-logo-potato-chip-frito-lay-brand-chips-miscellaneous-food-trademark.png"),
    )
    val nestleSubList = listOf(
        Brand(1, "Sub1Nestle", "https://w7.pngwing.com/pngs/342/57/png-transparent-nestle-logo-nestle-logo-nestle-ghana-ltd-nestle-blue-angle-building.png"),
        Brand(2, "Sub2Nestle", "https://w7.pngwing.com/pngs/342/57/png-transparent-nestle-logo-nestle-logo-nestle-ghana-ltd-nestle-blue-angle-building.png"),
        Brand(3, "Sub3Nestle", "https://w7.pngwing.com/pngs/342/57/png-transparent-nestle-logo-nestle-logo-nestle-ghana-ltd-nestle-blue-angle-building.png"),
    )
    val nikeSubList = listOf(
        Brand(1, "Sub1Nike", "https://w7.pngwing.com/pngs/654/821/png-transparent-swoosh-nike-just-do-it-logo-nike-angle-adidas-symbol.png"),
        Brand(2, "Sub2Nike", "https://w7.pngwing.com/pngs/654/821/png-transparent-swoosh-nike-just-do-it-logo-nike-angle-adidas-symbol.png"),
        Brand(3, "Sub3Nike", "https://w7.pngwing.com/pngs/654/821/png-transparent-swoosh-nike-just-do-it-logo-nike-angle-adidas-symbol.png"),
    )
    val pepsiSubList = listOf(
        Brand(1, "Sub1Pepsi", "https://w7.pngwing.com/pngs/236/376/png-transparent-pepsi-logo-fizzy-drinks-company-pepsi.png"),
        Brand(2, "Sub2Pepsi", "https://w7.pngwing.com/pngs/236/376/png-transparent-pepsi-logo-fizzy-drinks-company-pepsi.png"),
        Brand(3, "Sub3Pepsi", "https://w7.pngwing.com/pngs/236/376/png-transparent-pepsi-logo-fizzy-drinks-company-pepsi.png"),
    )
    val unileverSubList = listOf(
        Brand(1, "Sub1Unilever", "https://w7.pngwing.com/pngs/663/143/png-transparent-unilever-logo-unilever-logo-company-variety-miscellaneous-blue-text.png"),
        Brand(2, "Sub2Unilever", "https://w7.pngwing.com/pngs/663/143/png-transparent-unilever-logo-unilever-logo-company-variety-miscellaneous-blue-text.png"),
        Brand(3, "Sub3Unilever", "https://w7.pngwing.com/pngs/663/143/png-transparent-unilever-logo-unilever-logo-company-variety-miscellaneous-blue-text.png"),
    )

    val brandsList = listOf(
        Brand(1, "Adidas", "https://w7.pngwing.com/pngs/578/20/png-transparent-adidas-adidas-angle-text-logo.png", adidasSubList),
        Brand(2, "Algida", "https://w7.pngwing.com/pngs/504/936/png-transparent-ice-cream-good-humor-logo-wall-s-ice-cream.png", algidaSubList),
        Brand(3, "Cappy", "https://w7.pngwing.com/pngs/852/171/png-transparent-juice-cappy-squash-the-coca-cola-company-orange-juice-text-label-rectangle.png", cappySubList),
        Brand(4, "CocaCola", "https://w7.pngwing.com/pngs/717/116/png-transparent-coca-cola-logo-coca-cola-logo-company-business-cola-company-text-photography.png", cocacolaSubList),
        Brand(5, "Danone", "https://w7.pngwing.com/pngs/927/362/png-transparent-danone-logo-business-corporation-durex-blue-text-label.png", danoneSubList),
        Brand(6, "Lays", "https://w7.pngwing.com/pngs/559/457/png-transparent-lay-s-logo-lay-s-logo-potato-chip-frito-lay-brand-chips-miscellaneous-food-trademark.png", laysSubList),
        Brand(7, "Nestle", "https://w7.pngwing.com/pngs/342/57/png-transparent-nestle-logo-nestle-logo-nestle-ghana-ltd-nestle-blue-angle-building.png", nestleSubList),
        Brand(8, "Nike", "https://w7.pngwing.com/pngs/654/821/png-transparent-swoosh-nike-just-do-it-logo-nike-angle-adidas-symbol.png", nikeSubList),
        Brand(9, "Pepsi", "https://w7.pngwing.com/pngs/236/376/png-transparent-pepsi-logo-fizzy-drinks-company-pepsi.png", pepsiSubList),
        Brand(10, "Unilever", "https://w7.pngwing.com/pngs/663/143/png-transparent-unilever-logo-unilever-logo-company-variety-miscellaneous-blue-text.png", unileverSubList),
        Brand(11, "Adidas", "https://w7.pngwing.com/pngs/578/20/png-transparent-adidas-adidas-angle-text-logo.png",adidasSubList),
        Brand(12, "Algida", "https://w7.pngwing.com/pngs/504/936/png-transparent-ice-cream-good-humor-logo-wall-s-ice-cream.png", algidaSubList),
        Brand(13, "Cappy", "https://w7.pngwing.com/pngs/852/171/png-transparent-juice-cappy-squash-the-coca-cola-company-orange-juice-text-label-rectangle.png", cappySubList),
        Brand(14, "Coca Cola", "https://w7.pngwing.com/pngs/717/116/png-transparent-coca-cola-logo-coca-cola-logo-company-business-cola-company-text-photography.png", cocacolaSubList),
        Brand(15, "Danone", "https://w7.pngwing.com/pngs/927/362/png-transparent-danone-logo-business-corporation-durex-blue-text-label.png", danoneSubList),
        Brand(16, "Lays", "https://w7.pngwing.com/pngs/559/457/png-transparent-lay-s-logo-lay-s-logo-potato-chip-frito-lay-brand-chips-miscellaneous-food-trademark.png", laysSubList),
        Brand(17, "Nestle", "https://w7.pngwing.com/pngs/342/57/png-transparent-nestle-logo-nestle-logo-nestle-ghana-ltd-nestle-blue-angle-building.png", nestleSubList),
        Brand(18, "Nike", "https://w7.pngwing.com/pngs/654/821/png-transparent-swoosh-nike-just-do-it-logo-nike-angle-adidas-symbol.png", nikeSubList),
        Brand(19, "Pepsi", "https://w7.pngwing.com/pngs/236/376/png-transparent-pepsi-logo-fizzy-drinks-company-pepsi.png", pepsiSubList),
        Brand(20, "Unilever", "https://w7.pngwing.com/pngs/663/143/png-transparent-unilever-logo-unilever-logo-company-variety-miscellaneous-blue-text.png", unileverSubList),
        Brand(21, "Adidas", "https://w7.pngwing.com/pngs/578/20/png-transparent-adidas-adidas-angle-text-logo.png", adidasSubList),
        Brand(22, "Algida", "https://w7.pngwing.com/pngs/504/936/png-transparent-ice-cream-good-humor-logo-wall-s-ice-cream.png", algidaSubList),
        Brand(23, "Cappy", "https://w7.pngwing.com/pngs/852/171/png-transparent-juice-cappy-squash-the-coca-cola-company-orange-juice-text-label-rectangle.png", cappySubList),
        Brand(24, "CocaCola", "https://w7.pngwing.com/pngs/717/116/png-transparent-coca-cola-logo-coca-cola-logo-company-business-cola-company-text-photography.png", cocacolaSubList),
        Brand(25, "Danone", "https://w7.pngwing.com/pngs/927/362/png-transparent-danone-logo-business-corporation-durex-blue-text-label.png", danoneSubList),
        Brand(26, "Lays", "https://w7.pngwing.com/pngs/559/457/png-transparent-lay-s-logo-lay-s-logo-potato-chip-frito-lay-brand-chips-miscellaneous-food-trademark.png", laysSubList),
        Brand(27, "Nestle", "https://w7.pngwing.com/pngs/342/57/png-transparent-nestle-logo-nestle-logo-nestle-ghana-ltd-nestle-blue-angle-building.png", nestleSubList),
        Brand(28, "Nike", "https://w7.pngwing.com/pngs/654/821/png-transparent-swoosh-nike-just-do-it-logo-nike-angle-adidas-symbol.png", nikeSubList),
        Brand(29, "Pepsi", "https://w7.pngwing.com/pngs/236/376/png-transparent-pepsi-logo-fizzy-drinks-company-pepsi.png", pepsiSubList),
        Brand(30, "Unilever", "https://w7.pngwing.com/pngs/663/143/png-transparent-unilever-logo-unilever-logo-company-variety-miscellaneous-blue-text.png", unileverSubList)
    )
}